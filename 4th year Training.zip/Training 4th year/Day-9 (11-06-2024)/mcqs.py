'''
i=5
for i in range(7):
    i=i+2
    print("hi")
print(i)
'''

'''i=5
for i in range(7):
    #i=i+2
    print("hi")
print(i)
'''

'''for i in range(4):
    i=i+2000
    print("hi")
print(i)
'''

'''for i in [3,6,10,13]:# sequence
    print(i)'''

'''for i in {3,6,10,13}:
    print(i) #no sequence'''

'''a=[30,20,40,14]
for i in range(4):
    print(a[i])'''