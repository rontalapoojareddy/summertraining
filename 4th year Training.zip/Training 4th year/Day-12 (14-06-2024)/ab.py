'''
int fun(x)
     if(x is 1)
          return 1
     print(x)
     fun(x-1)
      print(x)
a=4
fun(a)
'''
'''
a="apple a day"
s=a[-1:-5:-1]
print(s)
'''
'''
b=5
a=2
i=4
while(i>3):
    i=i-1
    a=a+b
    b=b+a
print(a,b)
'''
'''
a="5674"
s=1
for i in a:
    s=s+i 
print(s)
'''
int i=3,a=6;
while(i> -1)
       a=a+2
       i=i-2
print a