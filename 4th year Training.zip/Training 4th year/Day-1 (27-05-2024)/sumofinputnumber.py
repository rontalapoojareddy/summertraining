a=input()
b=int(a[0])+int(a[1])
print(b)
