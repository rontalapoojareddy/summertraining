s="Placements"
t=""
i=0
for i in s:
    if (i in 'aeiou'):
        t=t+s.upper()
    else:
        print(s)