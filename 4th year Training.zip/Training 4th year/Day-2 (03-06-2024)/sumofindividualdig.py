def add(n):
    sum=0
    while(n):
        sum=sum+(n%10)
        n=n//10
    return sum
def prime(n):
    if(n in [2,3,5,7]):
        return m
    else:
        return m+1
n=int(input())
m=n
while():
    if n<10:
        l=prime(n)
    else:
        while(1):
            n=add(n)
            if n<10:
                break
        print(prime(n))