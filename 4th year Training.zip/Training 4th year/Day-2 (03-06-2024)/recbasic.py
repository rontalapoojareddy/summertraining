def fun(x):
    if(x==6):
        return
    print(x)
    fun(x+1)
    print(x)
fun(1)
print("hi")