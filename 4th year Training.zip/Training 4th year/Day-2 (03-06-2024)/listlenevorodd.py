list=[5,8,9,3,4,6]
if len(list)%2==0:
    print("Even")
else:
    print("Odd")
